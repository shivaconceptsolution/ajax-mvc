﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AjaxDemo.Models;
namespace AjaxDemo.Controllers
{
    public class AjaxController : Controller
    {
        Database1Entities db = new Database1Entities();
        //
        // GET: /Ajax/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult CreateStudent()
        {
            student s = new student();
            s.name = Request["name"];
            s.mobile = Request["mobile"];
            db.students.Add(s);
            db.SaveChanges();
            return Content("Data Submitted Successfully");
        }
        public ActionResult CheckName()
        {
            String name = Request["name"];
            var s = (from c in db.students where c.name.Equals(name) select c).FirstOrDefault();
            if (s != null)
                return Content("name already exist");
            else
                return Content("");
        }

        public ActionResult AjaxWithJquery()
        {
            return View();

        }

        public ActionResult AjaxCode(student s)
        {
            db.students.Add(s);
            db.SaveChanges();
            return Json(new{msg = "Successfully added " + s.name });

            

        }

    }
}
